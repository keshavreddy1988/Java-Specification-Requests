module org.codefx.demo.java9_.jsr305_ {
	requires jsr305;
	requires java.annotation;
}
